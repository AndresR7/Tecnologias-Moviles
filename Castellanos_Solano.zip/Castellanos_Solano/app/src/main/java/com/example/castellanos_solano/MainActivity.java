package com.example.castellanos_solano;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Producto> listaPrincipalProductos;
    private RecyclerView rvListadoProductos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cargarDatos();
        rvListadoProductos= findViewById(R.id.rv_listado_producto);
        Adaptador miAdaptador= new Adaptador(listaPrincipalProductos);
        miAdaptador.set
        rvListadoProductos.setLayoutManager(new LinearLayoutManager(this));


    }
    public void cargarDatos(){
        Producto producto1 = new Producto();
        producto1.setNombre("Computador HP Victus");
        producto1.setPrecio(6000000.0);
        producto1.setUrlImagen("https://exitocol.vtexassets.com/arquivos/ids/16741662-800-auto?v=638132004064800000&width=800&height=auto&aspect=true");
        Producto producto2 = new Producto("Teclado Dell", 20000.0, "https://img2.freepng.es/20180305/gxw/kisspng-computer-keyboard-computer-mouse-dell-ps-2-port-wi-a4-tech-black-keyboard-5a9d541f831165.2265179015202601275369.jpg");
        Producto producto3 = new Producto("Mouse Gaming", 30000.0, "https://cdn.imgbin.com/5/15/20/imgbin-computer-mouse-genesis-g66-optical-gaming-mouse-optical-mouse-gaming-laser-mouse-natec-genesis-gx68-black-pelihiiri-custom-pc-fan-grill-jB31qEksAqAY49WQ9qRqJiRH4.jpg");
        listaPrincipalProductos = new ArrayList<>();
        listaPrincipalProductos.add(producto1);
        listaPrincipalProductos.add(producto2);
        listaPrincipalProductos.add(producto3);
    }
}