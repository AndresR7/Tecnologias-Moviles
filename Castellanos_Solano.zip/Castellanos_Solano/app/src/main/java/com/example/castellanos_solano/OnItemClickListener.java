package com.example.castellanos_solano;

public class OnItemClickListener {
    public void onItemClick(Producto miProducto, int adapterPosition) {
    }

    public void setAdapter(Adaptador miAdaptador) {
    }
}
